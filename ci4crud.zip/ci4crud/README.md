# ci4crud
 My First CRUD using CodeIgniter 4
