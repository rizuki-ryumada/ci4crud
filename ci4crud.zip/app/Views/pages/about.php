<!doctype html>
<html lang="en">
  <head>
    <?= view('layout/header'); ?>

  </head>
  <body>
    <?= view('layout/navbar'); ?>
    <div class="container">
        <div class="row">
            <div class="col">
                <h1>About Us!</h1>

            </div>
        </div>
    </div>

    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quos laborum quae officia ab fugiat ut assumenda minima, deleniti quas magni inventore repudiandae sint quibusdam dolores quis! Earum deserunt ipsa ipsum?</p>

    <?= view('layout/footer'); ?>
  </body>
</html>