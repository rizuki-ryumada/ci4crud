<!doctype html>
<html lang="en">
  <head>
    <?= view('layout/header'); ?>

  </head>
  <body>
    <?= view('layout/navbar'); ?>
    <div class="container">
      <div class="row">
        <div class="col">
          <h1>Home!</h1>
          
        </div>
      </div>
    </div>

    <?= view('layout/footer'); ?>
  </body>
</html>