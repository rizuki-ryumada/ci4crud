<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="<?= base_url('assets'); ?>/node_modules/jquery/dist/jquery.min.js"></script>
<script src="<?= base_url('assets'); ?>/node_modules/popper.js/dist/popper.min.js"></script>
<script src="<?= base_url('assets'); ?>/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>